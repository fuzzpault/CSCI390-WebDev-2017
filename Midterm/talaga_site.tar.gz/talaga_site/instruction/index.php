<?php include("../f_top.php"); ?>

<title>Fuzzpault - Technology Instruction</title>
<meta name="keywords" content="Paul Talaga, Talaga, Web Design" />

<?php include("../f_middle.php"); ?>

    <h1>Technology Instruction</h1>
    <p>With 4 years of teaching at the University level, an equivalent time in tech support, and a lifetime of answering technology questions I'm perfectly suited for covering nearly any topic either in a classroom setting or one-on-one.</p>
    <p>No topic is out of bounds: from how to use a computer to getting on the internet to image editing, web design, computer repair, cryptography, and artificial intelligence.</p>
    <p>Academic Topics Taught in the Past:</p>
    <ul>
        <li>College Algebra</li>
        <li>Probability &amp; Statistics</li>
        <li>Discrete Mathematics</li>
        <li>Programming with C/Java/Lisp/Haskell/Java or Perl</li>
        <li>Artificial Intelligence &amp; Robotics</li>
        <li>Programming Language Theory</li>
    </ul>
    <p>Contact me with any question!</p>
    <hr>
    <h1>Technology Classes</h1>
    <ul>
        <li><h4><a href="/instruction/tfta.php">Web Technologies for the Artist - WCAA - Feb 1 thru March 8, 2011 - 7-9pm.</a></h4>
            <p>This 6 week course will teach the basics of the internet, HTML, and building your own website.
                Emphasis will be given for technologies useful for artists such as digital image editing and managing your own art related website.</p>
        </li>
    </ul>

<?php include("../f_bottom.php"); ?>
