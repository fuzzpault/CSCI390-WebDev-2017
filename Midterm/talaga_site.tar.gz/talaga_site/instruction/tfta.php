<?php include("../f_top.php"); ?>

<title>Fuzzpault - Web Technologies for the Artist</title>
<meta name="keywords" content="Paul Talaga, Talaga, Web Design" />

<?php include("../f_middle.php"); ?>

    <h1>Web Tech. for the Artist<br>Feb 1 - March 8, 2011<br>
        7-9pm</h1>
        
    <h2>Enroll Online Now via the <a href="http://waynecountyartsalliance.org/classes.php#08610">WCAA Classes page</a>.</h2>
    <p>Sponsored by the <a href="http://waynecountyartsalliance.org">Wayne County Arts Alliance</a>, I'll be teaching this 6 week course at the Wayne Highlands Middle School in Honesdale, PA on Tuesdays from 7-9pm.  Personal laptops are recommended, but lab computers will be available for those without.</p>
    <p>The web can be a great medium to publicize your work and express your own artistic talent on the worldwide stage.  This 6 week course will teach you the fundamentals of how the web works, what tools are needed to produce content, and how to design and publish your own website.  Rather than teach how to use expensive software from the beginning, we focus on fundamentals and show how a little knowledge and free software can be used to build almost any site from start to finish.  Topics covered include HTML, CSS, DNS, site hosting, FTP, digital image editing, search engine optimization (SEO), as well as optional topics including web scripting (PHP), JavaScript, Flash, and AJAX.</p>
    <ul>
        <li><strong>Location:</strong> Honesdale Middle School computer lab (MS Windows with Mac available).  Details and directions to come.</li>
        <li><strong>Date &amp; Time:</strong> Feb 1 - March 8th, Tuesday Evenings from 7:00 - 9:00PM.</li>
        <li><strong>Required Equipment &amp; Software</strong> Own laptop prefered (MS Windows or Mac), with lab computers (Windows) available if not.  Bring a USB memory stick to save your work if using lab computer.  Be prepared to download and install free software.
        <li><strong>Prerequisites:</strong> Basic computer knowledge including e-mail, MS Word, &amp; web surfing.  If you can point and click you'll do fine!</li>
        <li><strong>Class Format:</strong> Half lecture (about an hour), half hands-on (the remaining hour).  Be prepared to take many notes!</li>
        <li><strong>Class Goals:</strong> Students should understand enough web technologies to design, develop, and maintain their own website.  Furthermore, they should have a broad picture of the web, allowing them to understand and explore new opportunities online.</li>
        <li><strong>Class Text:</strong> None required, but helpful references include <ul>
                        <li>&quot;Web Design for Dummies&quot; by Lisa Lopuck (<a href="http://www.amazon.com/Web-Design-Dummies-Lisa-Lopuck/dp/0471781177/">Amazon</a>) (<a href="http://search.barnesandnoble.com/Web-Design-For-Dummies/Lisa-Lopuck/e/9780471781172/">B&amp;N</a>)</li>
                        <li>&quot;HTML, XHTML and CSS&quot; by Rob Huddleston (<a href="http://www.amazon.com/HTML-XHTML-CSS-blueprint-designing/dp/0470274360/">Amazon</a>) (<a href="http://search.barnesandnoble.com/HTML-XHTML-and-CSS/Rob-Huddleston/e/9780470274361/">B&amp;N</a>)</li>
                        <li>&quot;HTML, XHTML &amp; CSS for Dummies&quot; by Ed Tittel &amp; Jeff Noble (<a href="http://www.amazon.com/HTML-XHTML-Dummies-Computer-Tech/dp/0470916591/">Amazon</a>) (<a href="http://search.barnesandnoble.com/HTML-XHTML-CSS-For-Dummies/Ed-Tittel/e/9780470916599/">B&amp;N</a>)</li>
                        <li>&quot;The Complete IDIOT's guide to Creating a Website&quot; by Paul McFedries (<a href="http://www.amazon.com/Complete-Idiots-Guide-Creating-Website/dp/1592577881/">Amazon</a>) (<a href="http://search.barnesandnoble.com/Complete-Idiots-Guide-to-Creating-a-Website/Paul-McFedries/e/9781592577880/">B&amp;N</a>)</li>
                        <li>&quot;The Quick-and-Easy WEB SITE&quot; by Paula Peters (<a href="http://www.amazon.com/Quick---Easy-Web-Site-Presence/dp/1598696467/">Amazon</a>) (<a href="http://search.barnesandnoble.com/The-Quick-and-Easy-Web-Site/Paula-Peters/e/9781598696462">B&amp;N</a>)</li>
                        <li>&quot;Head First HTML with CSS &amp; XHTML&quot; by Elisabeth Freeman &amp; Eric Freeman (<a href="http://www.amazon.com/Head-First-HTML-CSS-XHTML/dp/059610197X/">Amazon</a>) (<a href="http://search.barnesandnoble.com/Head-First-HTML-with-CSS-XHTML/Eric-Freeman/e/9780596101978">B&amp;N</a>)</li>
                        <li>&quot;Don't Make Me Think&quot; by Steve Krug (<a href="http://www.amazon.com/Dont-Make-Me-Think-Usability/dp/0321344758/">Amazon</a>) (<a href="http://search.barnesandnoble.com/Dont-Make-Me-Think/Steve-Krug/e/9780321344755">B&amp;N</a>)</li>
                        <li>&quot;The Web Designer's Idea Book&quot; by Patrick McNeil (<a href="http://www.amazon.com/Web-Designers-Idea-Book-Vol/dp/160061972X">Amazon</a>) (<a href="http://search.barnesandnoble.com/The-Web-Designers-Idea-Book/Patrick-Mcneil/e/9781600610646">B&amp;N</a>)</li>
                    </ul>
                    <p>Pick one of the top 6 for technical knowledge, with the last two excellent general design references.  I suggest borrowing from the library to preview first!</p>
        </li>
    </ul>
    <h1>Preliminary Schedule</h1>
    <p><strong>Week 1:</strong> Class Intro, How the Internet Works (Overview), Lab Setup</p>
    <p><strong>Week 2:</strong> HTML, CSS and Friends (Part I)</p>
    <p><strong>Week 3:</strong> Development Environment &amp; Getting it Online</p>
    <p><strong>Week 4:</strong> Graphics! (HTML Part II)</p>
    <p><strong>Week 5:</strong> Page Layout (HTML Part III)</p>
    <p><strong>Week 6:</strong> SEO and Extra Topics: JavaScript, AJAX, Dynamic Content, Facebook Integration</p>
    <p>Schedule may change based on class ability or interests.  It is hoped students will be able to design, create, and maintain their own website by the end of class.  Classes will consist of half lecture (about an hour) followed by hands-on practice to reinforce topics taught.   

<?php include("../f_bottom.php"); ?>
