<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" /> 
<link href="/fuzz.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
</head>
<body>
    <div style="float:left"><h2><a href="/">Paul Talaga</a></h2></div>
    <div style="float:right"><h2><a href="/">Fuzzpault Technologies LLC</a></h2></div>
    <div class="clear"></div>
<hr />
<div class="menu">
    Services
    <ul> 
        <li><a href="/support">Support</a></li>
        <li><a href="/instruction">Instruction</a>
            <ul>
                <li><a href="/instruction/tfta.php">Web Class</a></li>
            </ul>
        </li>
    </ul>
    <hr />
    Academics
    <ul>
        <li><a href="/publications/">Publications</a></li>
    </ul>
    <hr />
    Other
    <ul>
            <li><a href="/photography/">Photography</a></li>
    </ul>
</div>
<div class="body">
