<?php include("../f_top.php"); ?>

<title>Fuzzpault - Computer Support</title>
<meta name="keywords" content="Paul Talaga, Talaga, Web Design" />

<?php include("../f_middle.php"); ?>

    <h1>Computer Support</h1>
    <p>Computer slow? Infected?  Home network not working right?  No idea how to install your A/V equipment?  Today's technology can be a minefield of wires and settings, let me get it all working and explain it all.  With over 10 years of tech support experience I'll get you up and running.</p>
    <ul>
        <li>Windows XP / Vista / 7</li>
        <li>Mac</li>
        <li>Linux / Unix</li>
        <li>Network installation and repair</li>
        <li>Desktop repair and upgrades</li>
        <li>Laptop repair and upgrades</li>
        <li>A/V setup and repair</li>
    </ul>
    <p>Home service available!  Contact me for rates or a quote.</p>
    

<?php include("../f_bottom.php"); ?>
