</div>
<div class="clear"></div>
<!-- Footer -->
<hr class="flare" />
<div class="center footer">
    &copy; <?php echo date('Y'); ?>  Fuzzpault Technologies LLC<br/>
paul at fuzzpault dot com
</div>
</body>

</html>
