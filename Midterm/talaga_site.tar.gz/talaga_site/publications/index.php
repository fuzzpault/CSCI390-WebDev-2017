<?php include("../f_top.php"); ?>

<title>Fuzzpault - Academic Publications</title>
<meta name="keywords" content="Paul Talaga, Talaga, Web Design" />

<?php include("../f_middle.php"); ?>

    <h1>Publications</h1>
    <ul>
        <li><span class="b">Guaranteeing Strong (X)HTML Compliance for Dynamic Web Applications</span><br/>
            Paul G. Talaga, Steve Chapin<br/>
            <span class="i">Accepted for presentation &amp; publication at WEBIST 2011</span>
        </li>
        <li><span class="b">Combining AIMA and LEGO Mindstorms in an Artificial Intelligence Course to Build Real World Robots</span> (<a href="http://portal.acm.org/citation.cfm?id=1409873.1409885&coll=DL&dl=GUIDE&CFID=5168811&CFTOKEN=86729824">ACM</a>)<br/>
            Paul G. Talaga, Jae C. Oh<br/>
            <span class="i">Journal of Computing Sciences in Colleges, Vol 24, Issue 3 (January 2009).</span>
        </li>
        <li><span class="b">Enforcing Request Integrity in Web Applications</span> (<a href="http://portal.acm.org/citation.cfm?id=1875967">ACM</a>)<br/>
            Karthick Jayaraman, Gregg Lewandowski, Paul G. Talaga, and Steve Chapin<br/> 
            <span class="i">In Proceedings of 24th Annual Working Conference on Data and Applications Security 2010.</span>
        </li>
        <li><span class="b">Modeling User Interactions (for Fun) and Profit: Preventing Workflow-based Attacks in Web Applications</span><br/>
            Karthick Jayaraman, Paul G. Talaga, Grzegorz Lewandowski, and Steve J. Chapin<br/>
            <span class="i">In Proceedings of the 16th Pattern Languages of Programs Conference (Chicago, Aug 28-30, 2009.). PLoP '09.</span>
        </li>

    </ul>
    

<?php include("../f_bottom.php"); ?>
