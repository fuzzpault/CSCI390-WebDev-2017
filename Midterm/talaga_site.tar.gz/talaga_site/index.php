<?php include("f_top.php"); ?>

<title>Fuzzpault - Paul Talaga</title>
<meta name="keywords" content="Paul Talaga, Talaga, Web Design, Haskell, CHXHtml, Photography, Linux, Unix" />
<?php include("f_middle.php"); ?>

    <h1>Welcome!</h1>
    <p>
    Welcome to my site!  Enjoy!</p>
    <div class="centerblock" style="width:320px;">
        <img src="images/DSC_4966.JPG" alt="Paul Talaga"/>
    </div>

<?php include("f_bottom.php"); ?>
