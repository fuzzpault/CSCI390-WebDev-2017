<?php include("../f_top.php"); ?>

<title>Fuzzpault - Photography</title>
<meta name="keywords" content="Paul Talaga, Talaga, photography, outdoor photography" />
<script src="slideshow-c.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
var f=new Array()
<?php  
// change the next line with trailing slash!!!!!
$folder = 'slideshow/';
$dir = opendir($folder);
$i = 0;
while($file = readdir($dir)){
	if(($file != '.') && ($file != '..')){
	echo 'f[', $i, ']=["',$folder,$file,'", "", ""]',"\n";
	$i = $i + 1;
	}
}
?>
//-->
</script>

<?php include("../f_middle.php"); ?>

    <h1>Photography</h1>
    <p>My love of the outdoors and technology have lead me to outdoor nature photography.  Capturing the harshness, simplicity, and stillness of the outdoors faithfully is my goal.  What you see
    is what was there; no fancy photoshop tricks.</p>
    <p>Any photo shown in the slideshow below is available for sale by download or in prints.  Quality is suitable for printing up to 11x17. </p>
    <div class="block" style="width:100%;"><div style="margin:auto;width:600px;">
        <noscript>
          <img src="slideshow/zDSC_8619" alt="Frozen" height="399" width="600"/>
        </noscript> 
        <script type="text/javascript">new fadeshow(f,600,399,0,4500,1,1) </script>
        </div>
    </div>

    

<?php include("../f_bottom.php"); ?>
